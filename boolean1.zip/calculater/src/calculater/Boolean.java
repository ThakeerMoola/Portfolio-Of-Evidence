/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculater;
import java.util.Scanner; //scanner imported to ask the user a input
/**
 *
 * @author moola
 */


public class Boolean {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner Inequalities = new Scanner(System.in);  //to get input from the user
        int num1; //appointing names for the variables
        int num2; //appointing names for the variables
        
                System.out.println("Please enter first number"); //pirnt statement for user
                num1 = Inequalities.nextInt();  //asking user for input
                
                System.out.println("Please enter second number"); //pirnt statement for user
                num2 = Inequalities.nextInt();  //asking user for input
                
                boolean N1 = (num1>num2);
                 System.out.println("is " + num1 + " more than " + num2 + " " + N1); //this is more than
                 
                boolean N2 = (num1<num2);
                System.out.println("is " + num1 + " less than " + num2 + " " + N2); //this is less than
                
                boolean N3 = (num1==num2);
                System.out.println("is " + num1 + " equal to " + num2 + " " + N3); //this is equal to
                
                boolean N4 = (num1<=num2);
                System.out.println("is " + num1 + " less than or equal to " + num2 + " " + N4); //this is less than or equal to
                
                boolean N5 = (num1!=num2);
                System.out.println("is " + num1 + " not equal " + num2 + " " + N5); //this is not equal to 
                
                boolean N6 = (num1>=num2); 
                System.out.println("is " + num1 + " more than or equal " + num2 + " " + N6); //this os more than and or equal to 
    }
    
}
